import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { UserAvatar } from "@/components/ui/user-avatar";
import { Button } from "@/components/ui/button";
import { MapPinIcon, PencilIcon } from "lucide-react";
import { ProfileData } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

interface ProfileCardProps {
  profile: ProfileData;
}

export default function ProfileCard({ profile }: ProfileCardProps) {
  const { toast } = useToast();

  const handleEditProfile = () => {
    toast({
      title: "Edit Profile",
      description: "Profile editing functionality coming soon!",
    });
  };

  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <div className="flex flex-col items-center text-center mb-6">
          <UserAvatar
            user={{ name: profile.name, image: profile.profilePicture }}
            className="h-24 w-24 border-4 border-neutral-200 dark:border-neutral-600 mb-4"
          />
          
          <h2 className="text-xl font-bold">{profile.name}</h2>
          <p className="text-neutral-500 dark:text-neutral-400">{profile.headline}</p>
          
          <div className="flex items-center mt-2">
            <MapPinIcon className="text-neutral-400 mr-2 h-4 w-4" />
            <span className="text-sm text-neutral-500 dark:text-neutral-400">{profile.location}</span>
          </div>
        </div>

        <div className="border-t border-neutral-200 dark:border-neutral-600 pt-4">
          <div className="mb-4">
            <h3 className="text-sm uppercase font-semibold text-neutral-500 dark:text-neutral-400 mb-2">Current Position</h3>
            <p className="font-medium">{profile.currentPosition.title}</p>
            <p className="text-neutral-500 dark:text-neutral-400">{profile.currentPosition.company}</p>
          </div>

          <div className="mb-4">
            <h3 className="text-sm uppercase font-semibold text-neutral-500 dark:text-neutral-400 mb-2">Education</h3>
            <p className="font-medium">{profile.education.school}</p>
            <p className="text-neutral-500 dark:text-neutral-400">{profile.education.degree}</p>
          </div>

          <div>
            <h3 className="text-sm uppercase font-semibold text-neutral-500 dark:text-neutral-400 mb-2">Skills</h3>
            <div className="flex flex-wrap gap-2">
              {profile.skills.map((skill, index) => (
                <span 
                  key={index} 
                  className="bg-neutral-100 dark:bg-neutral-600 text-neutral-800 dark:text-neutral-200 text-xs px-3 py-1 rounded-full"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>
      </CardContent>

      <CardFooter className="bg-neutral-50 dark:bg-neutral-600 px-6 py-4">
        <Button className="w-full flex items-center justify-center gap-2" onClick={handleEditProfile}>
          <PencilIcon className="h-4 w-4" />
          Edit Profile
        </Button>
      </CardFooter>
    </Card>
  );
}
