import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

interface UserAvatarProps {
  user: {
    name?: string | null;
    image?: string | null;
    profilePicture?: string | null;
  };
  className?: string;
}

export function UserAvatar({ user, className }: UserAvatarProps) {
  return (
    <Avatar className={cn("border-2 border-neutral-200 dark:border-neutral-600", className)}>
      <AvatarImage src={user.image || user.profilePicture || undefined} alt={user.name || "User"} />
      <AvatarFallback>
        {user.name ? getInitials(user.name) : "U"}
      </AvatarFallback>
    </Avatar>
  );
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .substring(0, 2);
}
