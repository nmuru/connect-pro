import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserAvatar } from "@/components/ui/user-avatar";
import { UserPlusIcon, XIcon, FilterIcon } from "lucide-react";
import { peopleToFollow as initialPeopleToFollow } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

export default function PeopleToFollow() {
  const [people, setPeople] = useState(initialPeopleToFollow);
  const { toast } = useToast();

  const handleFollowUser = (id: string) => {
    setPeople(people.filter(person => person.id !== id));
    toast({
      title: "Following new connection",
      description: "You are now following this user!",
    });
  };

  const handleIgnoreRecommendation = (id: string) => {
    setPeople(people.filter(person => person.id !== id));
    toast({
      title: "Recommendation ignored",
      description: "This recommendation has been removed.",
    });
  };

  const handleViewAll = () => {
    toast({
      title: "View All People",
      description: "Viewing all people feature coming soon!",
    });
  };

  const handleFilter = () => {
    toast({
      title: "Filter People",
      description: "Filtering functionality coming soon!",
    });
  };

  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold">People to Follow</h2>
          <div>
            <Button variant="ghost" size="icon" className="mr-2" onClick={handleFilter}>
              <FilterIcon className="h-4 w-4 text-neutral-400 hover:text-neutral-500 dark:text-neutral-500 dark:hover:text-neutral-400" />
            </Button>
            <Button variant="link" className="text-primary" onClick={handleViewAll}>
              View All
            </Button>
          </div>
        </div>
        
        <div className="space-y-4">
          {people.length > 0 ? (
            people.map(person => (
              <div 
                key={person.id} 
                className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-lg flex items-center justify-between"
              >
                <div className="flex items-center">
                  <UserAvatar
                    user={{ name: person.name, image: person.profilePicture }}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div className="ml-4">
                    <h3 className="font-medium">{person.name}</h3>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">
                      {person.position} at {person.company} • {person.followers.toLocaleString()} followers
                    </p>
                    {person.mutualConnections > 0 && (
                      <p className="text-xs text-primary mt-1">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          className="h-3 w-3 inline mr-1" 
                          fill="none" 
                          viewBox="0 0 24 24" 
                          stroke="currentColor"
                        >
                          <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={2} 
                            d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" 
                          />
                        </svg>
                        {person.mutualConnections} mutual connection{person.mutualConnections !== 1 ? 's' : ''}
                      </p>
                    )}
                    {person.source && person.mutualConnections === 0 && (
                      <p className="text-xs text-primary mt-1">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          className="h-3 w-3 inline mr-1" 
                          fill="none" 
                          viewBox="0 0 24 24" 
                          stroke="currentColor"
                        >
                          <path 
                            d="M12 14l9-5-9-5-9 5 9 5z" 
                          />
                          <path 
                            d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" 
                          />
                          <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            strokeWidth={2} 
                            d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" 
                          />
                        </svg>
                        Attended {person.source}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-neutral-500 dark:text-neutral-300 hover:text-neutral-700 dark:hover:text-neutral-100 mr-3"
                    onClick={() => handleIgnoreRecommendation(person.id)}
                  >
                    <XIcon className="h-4 w-4" />
                  </Button>
                  <Button 
                    size="sm" 
                    className="flex items-center gap-1"
                    onClick={() => handleFollowUser(person.id)}
                  >
                    <UserPlusIcon className="h-4 w-4" />
                    Follow
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-neutral-500 dark:text-neutral-400">
              No more people to follow right now.
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
