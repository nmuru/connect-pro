import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserAvatar } from "@/components/ui/user-avatar";
import { BookmarkIcon, ThumbsUpIcon, MessageSquareIcon, TagIcon } from "lucide-react";
import { postsToRead as initialPostsToRead } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

export default function PostsToRead() {
  const [posts, setPosts] = useState(initialPostsToRead);
  const { toast } = useToast();

  const handleSaveForLater = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId ? { ...post, saved: !post.saved } : post
    ));
    
    const post = posts.find(p => p.id === postId);
    if (post) {
      toast({
        title: post.saved ? "Post removed from saved items" : "Post saved for later",
        description: post.saved 
          ? "The post has been removed from your saved items." 
          : "The post will be available in your saved items.",
      });
    }
  };

  const handleViewAll = () => {
    toast({
      title: "View All Posts",
      description: "Viewing all posts feature coming soon!",
    });
  };

  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold">Posts to Read</h2>
          <Button variant="link" className="text-primary" onClick={handleViewAll}>
            View All
          </Button>
        </div>
        
        <div className="space-y-4">
          {posts.map(post => (
            <div key={post.id} className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-lg">
              <div className="flex justify-between">
                <div className="flex items-center">
                  <UserAvatar
                    user={{ name: post.author.name, image: post.author.profilePicture }}
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <div className="ml-3">
                    <h3 className="font-medium">{post.author.name}</h3>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400">
                      {post.author.position} at {post.author.company} • {post.timeAgo}
                    </p>
                  </div>
                </div>
                <div className="flex">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className={post.saved ? "text-primary" : "text-neutral-500 dark:text-neutral-300 hover:text-neutral-700 dark:hover:text-neutral-100"}
                    onClick={() => handleSaveForLater(post.id)}
                  >
                    <BookmarkIcon className="h-4 w-4" fill={post.saved ? "currentColor" : "none"} />
                  </Button>
                </div>
              </div>
              
              <div className="mt-3">
                <h4 className="font-medium mb-2">{post.title}</h4>
                <p className="text-sm text-neutral-600 dark:text-neutral-300 line-clamp-2">
                  {post.content}
                </p>
              </div>
              
              <div className="mt-3 text-sm text-neutral-500 dark:text-neutral-400 flex items-center flex-wrap">
                <span className="flex items-center mr-4">
                  <ThumbsUpIcon className="h-4 w-4 mr-1" />
                  {post.likes.toLocaleString()}
                </span>
                <span className="flex items-center mr-4">
                  <MessageSquareIcon className="h-4 w-4 mr-1" />
                  {post.comments.toLocaleString()}
                </span>
                <span className="flex items-center">
                  <TagIcon className="h-4 w-4 mr-1" />
                  {post.tags.join(", ")}
                </span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
