import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRightIcon } from "lucide-react";
import { skillsToLearn } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

export default function SkillsToLearn() {
  const { toast } = useToast();

  const handleExploreSkill = (skillName: string) => {
    toast({
      title: `Explore ${skillName}`,
      description: `Exploring resources to learn ${skillName}.`,
    });
  };

  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <h2 className="text-lg font-bold mb-4">Skills to Develop</h2>
        
        <div className="space-y-3">
          {skillsToLearn.map((skill, index) => (
            <div 
              key={index} 
              className="bg-neutral-50 dark:bg-neutral-600 p-3 rounded-md flex justify-between items-center"
            >
              <div>
                <h3 className="font-medium">{skill.name}</h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400">{skill.description}</p>
              </div>
              <div className="flex items-center">
                <span className="text-xs font-medium text-primary mr-3">+{skill.jobIncrease}% more jobs</span>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-neutral-500 dark:text-neutral-300 hover:text-primary-600 dark:hover:text-primary-400"
                  onClick={() => handleExploreSkill(skill.name)}
                >
                  <ArrowRightIcon className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
