import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { defaultJobGoals } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

export default function JobGoalsForm() {
  const [jobGoals, setJobGoals] = useState(defaultJobGoals);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Job Goals Updated",
      description: "Your job preferences have been saved successfully!",
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { id, value } = e.target;
    setJobGoals(prev => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (id: string, value: string) => {
    setJobGoals(prev => ({ ...prev, [id]: value }));
  };

  const handleCheckboxChange = (field: keyof typeof jobGoals.jobTypes, checked: boolean) => {
    setJobGoals(prev => ({
      ...prev,
      jobTypes: { ...prev.jobTypes, [field]: checked }
    }));
  };

  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <h2 className="text-lg font-bold mb-4">Your Job Goals</h2>
        
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div>
            <Label htmlFor="role" className="block text-sm font-medium mb-1">Desired Role</Label>
            <Input 
              id="role" 
              value={jobGoals.role} 
              onChange={handleInputChange}
              className="w-full"
            />
          </div>
          
          <div>
            <Label htmlFor="location" className="block text-sm font-medium mb-1">Preferred Location</Label>
            <Input 
              id="location" 
              value={jobGoals.location} 
              onChange={handleInputChange}
              className="w-full"
            />
          </div>
          
          <div>
            <Label htmlFor="industry" className="block text-sm font-medium mb-1">Target Industry</Label>
            <Select 
              value={jobGoals.industry} 
              onValueChange={(value) => handleSelectChange("industry", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tech">Technology</SelectItem>
                <SelectItem value="finance">Finance</SelectItem>
                <SelectItem value="healthcare">Healthcare</SelectItem>
                <SelectItem value="education">Education</SelectItem>
                <SelectItem value="ecommerce">E-commerce</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label className="block text-sm font-medium mb-1">Job Type</Label>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center">
                <Checkbox 
                  id="fullTime" 
                  checked={jobGoals.jobTypes.fullTime} 
                  onCheckedChange={(checked) => handleCheckboxChange("fullTime", checked as boolean)}
                  className="mr-2"
                />
                <Label htmlFor="fullTime" className="text-sm">Full-time</Label>
              </div>
              <div className="flex items-center">
                <Checkbox 
                  id="partTime" 
                  checked={jobGoals.jobTypes.partTime} 
                  onCheckedChange={(checked) => handleCheckboxChange("partTime", checked as boolean)}
                  className="mr-2"
                />
                <Label htmlFor="partTime" className="text-sm">Part-time</Label>
              </div>
              <div className="flex items-center">
                <Checkbox 
                  id="remote" 
                  checked={jobGoals.jobTypes.remote} 
                  onCheckedChange={(checked) => handleCheckboxChange("remote", checked as boolean)}
                  className="mr-2"
                />
                <Label htmlFor="remote" className="text-sm">Remote</Label>
              </div>
              <div className="flex items-center">
                <Checkbox 
                  id="contract" 
                  checked={jobGoals.jobTypes.contract} 
                  onCheckedChange={(checked) => handleCheckboxChange("contract", checked as boolean)}
                  className="mr-2"
                />
                <Label htmlFor="contract" className="text-sm">Contract</Label>
              </div>
            </div>
          </div>
          
          <div>
            <Label htmlFor="salaryRange" className="block text-sm font-medium mb-1">Desired Salary Range</Label>
            <Select 
              value={jobGoals.salaryRange} 
              onValueChange={(value) => handleSelectChange("salaryRange", value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select salary range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="100k-125k">$100K - $125K</SelectItem>
                <SelectItem value="125k-150k">$125K - $150K</SelectItem>
                <SelectItem value="150k-175k">$150K - $175K</SelectItem>
                <SelectItem value="175k-200k">$175K - $200K</SelectItem>
                <SelectItem value="200k+">$200K+</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button type="submit" className="w-full">
            Update Job Goals
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
