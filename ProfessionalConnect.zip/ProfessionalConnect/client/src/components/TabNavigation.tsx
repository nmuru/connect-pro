import { Link } from "wouter";
import { HomeIcon, LightbulbIcon, UserIcon, BriefcaseIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface TabNavigationProps {
  activeTab: string;
}

export default function TabNavigation({ activeTab }: TabNavigationProps) {
  const tabs = [
    {
      id: "home",
      label: "Home",
      icon: HomeIcon,
      href: "/app/home",
    },
    {
      id: "interests",
      label: "Interests",
      icon: LightbulbIcon,
      href: "/app/interests",
    },
    {
      id: "networking",
      label: "Networking",
      icon: UserIcon,
      href: "/app/networking",
    },
    {
      id: "jobs",
      label: "Jobs",
      icon: BriefcaseIcon,
      href: "/app/jobs",
    },
  ];

  return (
    <div className="bg-white dark:bg-neutral-700 shadow-sm sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex -mb-px relative" aria-label="Tabs">
          {/* Tab indicator */}
          <div 
            className="absolute bottom-0 h-1 bg-primary transition-all duration-300" 
            style={{ 
              width: `${100 / tabs.length}%`, 
              left: `${tabs.findIndex(tab => tab.id === activeTab) * (100 / tabs.length)}%` 
            }}
          />
          
          {tabs.map((tab) => (
            <Link
              key={tab.id}
              href={tab.href}
              className={cn(
                "flex-1 inline-flex items-center justify-center py-4 px-1 text-center border-transparent font-medium text-sm focus:outline-none transition-colors",
                tab.id === activeTab
                  ? "text-primary"
                  : "text-neutral-500 hover:text-neutral-700 dark:text-neutral-300 dark:hover:text-white"
              )}
            >
              <tab.icon className="h-5 w-5 mr-2" />
              <span className="hidden sm:inline">{tab.label}</span>
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
}
