import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusCircleIcon } from "lucide-react";
import { suggestedInterests } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

export default function SuggestedInterests() {
  const { toast } = useToast();

  const handleAddInterest = (interest: string) => {
    toast({
      title: "Interest Added",
      description: `"${interest}" has been added to your interests.`,
    });
  };

  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <h2 className="text-lg font-bold mb-4">Suggested for You</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {suggestedInterests.map((interest, index) => (
            <div key={index} className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-lg flex justify-between items-center">
              <div>
                <h3 className="font-medium">{interest.name}</h3>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">
                  Based on your interest in {interest.basedOn}
                </p>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-primary hover:text-primary-600"
                onClick={() => handleAddInterest(interest.name)}
              >
                <PlusCircleIcon className="h-6 w-6" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
