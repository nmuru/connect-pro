// User profile data (based on LinkedIn profile structure)
export interface ProfileData {
  id: string;
  name: string;
  headline: string;
  location: string;
  profilePicture: string;
  currentPosition: {
    title: string;
    company: string;
    industry: string;
  };
  education: {
    school: string;
    degree: string;
    yearCompleted: string;
  };
  skills: string[];
  connections: number;
  certifications: string[];
}

export const profileData: ProfileData = {
  id: "123456789",
  name: "Alex Johnson",
  headline: "Senior Software Engineer",
  location: "San Francisco, CA",
  profilePicture: "https://randomuser.me/api/portraits/men/32.jpg",
  currentPosition: {
    title: "Senior Software Engineer",
    company: "TechCorp Inc.",
    industry: "Technology",
  },
  education: {
    school: "Stanford University",
    degree: "M.S. Computer Science",
    yearCompleted: "2018",
  },
  skills: [
    "JavaScript", 
    "React", 
    "Node.js", 
    "Python", 
    "Cloud Architecture"
  ],
  connections: 289,
  certifications: [
    "AWS Certified Solutions Architect",
    "Google Cloud Professional Developer"
  ]
};

// Interest categories for the Interests tab
export interface InterestCategory {
  name: string;
  topics: { id: string; label: string; checked: boolean }[];
}

export const interestCategories: InterestCategory[] = [
  {
    name: "Technology",
    topics: [
      { id: "tech-ai", label: "Artificial Intelligence", checked: true },
      { id: "tech-cloud", label: "Cloud Computing", checked: true },
      { id: "tech-security", label: "Cybersecurity", checked: false },
      { id: "tech-ml", label: "Machine Learning", checked: false }
    ]
  },
  {
    name: "Business",
    topics: [
      { id: "business-startup", label: "Startups", checked: true },
      { id: "business-leadership", label: "Leadership", checked: false },
      { id: "business-marketing", label: "Digital Marketing", checked: false },
      { id: "business-product", label: "Product Management", checked: true }
    ]
  },
  {
    name: "Career Development",
    topics: [
      { id: "career-remote", label: "Remote Work", checked: true },
      { id: "career-freelance", label: "Freelancing", checked: false },
      { id: "career-negotiation", label: "Salary Negotiation", checked: false },
      { id: "career-interview", label: "Interview Preparation", checked: false }
    ]
  }
];

export interface SuggestedInterest {
  name: string;
  basedOn: string;
}

export const suggestedInterests: SuggestedInterest[] = [
  { name: "Blockchain Technology", basedOn: "Cloud Computing" },
  { name: "UX Design", basedOn: "Product Management" },
  { name: "DevOps", basedOn: "technical background" },
  { name: "Data Science", basedOn: "Artificial Intelligence" }
];

// Networking data
export interface Person {
  id: string;
  name: string;
  position: string;
  company: string;
  followers: number;
  mutualConnections: number;
  profilePicture: string;
  source?: string;
}

export const peopleToFollow: Person[] = [
  {
    id: "1",
    name: "Michael Roberts",
    position: "CTO",
    company: "InnovateTech",
    followers: 5000,
    mutualConnections: 3,
    profilePicture: "https://randomuser.me/api/portraits/men/42.jpg",
    source: "mutual connections"
  },
  {
    id: "2",
    name: "Sarah Chen",
    position: "AI Research Lead",
    company: "DataTech",
    followers: 8000,
    mutualConnections: 0,
    profilePicture: "https://randomuser.me/api/portraits/women/28.jpg",
    source: "alma mater"
  }
];

export interface Post {
  id: string;
  author: {
    name: string;
    position: string;
    company: string;
    profilePicture: string;
  };
  title: string;
  content: string;
  likes: number;
  comments: number;
  tags: string[];
  timeAgo: string;
  saved: boolean;
}

export const postsToRead: Post[] = [
  {
    id: "1",
    author: {
      name: "Mark Wilson",
      position: "Product Manager",
      company: "TechCorp",
      profilePicture: "https://randomuser.me/api/portraits/men/77.jpg"
    },
    title: "The Future of Remote Work in Tech",
    content: "As companies adapt to the post-pandemic world, we're seeing interesting trends in how tech organizations are approaching remote work policies. Here are my observations...",
    likes: 256,
    comments: 42,
    tags: ["Remote Work"],
    timeAgo: "2d ago",
    saved: false
  },
  {
    id: "2",
    author: {
      name: "David Kim",
      position: "Engineering Director",
      company: "CloudScale",
      profilePicture: "https://randomuser.me/api/portraits/men/54.jpg"
    },
    title: "5 AI Technologies Changing Software Development",
    content: "AI is revolutionizing how we write, test, and deploy code. Here are 5 AI-powered tools that every developer should know about in 2023...",
    likes: 432,
    comments: 87,
    tags: ["Artificial Intelligence"],
    timeAgo: "5d ago",
    saved: false
  }
];

// Jobs data
export interface JobGoals {
  role: string;
  location: string;
  industry: string;
  jobTypes: {
    fullTime: boolean;
    partTime: boolean;
    remote: boolean;
    contract: boolean;
  };
  salaryRange: string;
}

export const defaultJobGoals: JobGoals = {
  role: "Senior Software Engineer",
  location: "San Francisco, Remote",
  industry: "tech",
  jobTypes: {
    fullTime: true,
    partTime: false,
    remote: true,
    contract: false
  },
  salaryRange: "125k-150k"
};

export interface Skill {
  name: string;
  description: string;
  jobIncrease: number;
}

export const skillsToLearn: Skill[] = [
  {
    name: "React Native",
    description: "High demand in job market",
    jobIncrease: 35
  },
  {
    name: "GraphQL",
    description: "Growing adoption rate",
    jobIncrease: 28
  },
  {
    name: "Kubernetes",
    description: "Essential for DevOps roles",
    jobIncrease: 42
  }
];

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  skills: string[];
  postedTime: string;
  applicants: number;
  companyLogo: string;
  saved: boolean;
}

export const recommendedJobs: Job[] = [
  {
    id: "1",
    title: "Senior Software Engineer",
    company: "TechCorp Inc.",
    location: "San Francisco, CA",
    salary: "$140K - $165K",
    skills: ["JavaScript", "React", "Node.js"],
    postedTime: "2 days ago",
    applicants: 82,
    companyLogo: "https://ui-avatars.com/api/?name=TechCorp&background=0D8ABC&color=fff",
    saved: false
  },
  {
    id: "2",
    title: "Frontend Engineer (Remote)",
    company: "InnovaTech",
    location: "Remote",
    salary: "$125K - $150K",
    skills: ["React", "TypeScript", "GraphQL"],
    postedTime: "1 week ago",
    applicants: 146,
    companyLogo: "https://ui-avatars.com/api/?name=InnovaTech&background=833AB4&color=fff",
    saved: false
  }
];

export interface Course {
  id: string;
  title: string;
  provider: string;
  duration: string;
  rating: number;
  reviews: number;
  icon: string;
}

export const recommendedCourses: Course[] = [
  {
    id: "1",
    title: "Advanced React Patterns",
    provider: "Frontend Masters",
    duration: "8 hours",
    rating: 4.5,
    reviews: 2100,
    icon: "code"
  },
  {
    id: "2",
    title: "Cloud Architecture Fundamentals",
    provider: "Cloud Academy",
    duration: "12 hours",
    rating: 4.0,
    reviews: 1800,
    icon: "cloud"
  }
];

export const quickStats = {
  profileViews: 23,
  profileCompletion: 85,
  newConnections: 12
};
