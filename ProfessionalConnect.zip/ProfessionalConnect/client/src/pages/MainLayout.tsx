import { useEffect, useState } from "react";
import { useRoute, useLocation } from "wouter";
import Header from "../components/Header";
import TabNavigation from "../components/TabNavigation";
import ProfileCard from "../components/profile/ProfileCard";
import QuickStats from "../components/profile/QuickStats";
import RecommendationCards from "../components/home/RecommendationCards";
import InterestsList from "../components/interests/InterestsList";
import SuggestedInterests from "../components/interests/SuggestedInterests";
import NetworkOverview from "../components/networking/NetworkOverview";
import PeopleToFollow from "../components/networking/PeopleToFollow";
import PostsToRead from "../components/networking/PostsToRead";
import JobGoalsForm from "../components/jobs/JobGoalsForm";
import RecommendedJobs from "../components/jobs/RecommendedJobs";
import RecommendedCourses from "../components/jobs/RecommendedCourses";
import SkillsToLearn from "../components/jobs/SkillsToLearn";
import { useUser } from "../context/UserContext";

const MainLayout = () => {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/app/:tab");
  const { profile, isAuthenticated } = useUser();
  
  const [activeTab, setActiveTab] = useState("home");

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
      return;
    }

    if (match && params.tab) {
      setActiveTab(params.tab);
    } else {
      setLocation("/app/home");
    }
  }, [match, params, isAuthenticated, setLocation]);

  if (!profile) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }

  return (
    <div className="flex flex-col min-h-screen bg-neutral-100 dark:bg-neutral-800 transition-colors duration-300">
      <Header />
      <TabNavigation activeTab={activeTab} />
      
      <main className="flex-1 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Home Tab */}
          {activeTab === "home" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <ProfileCard profile={profile} />
              </div>
              <div className="lg:col-span-2 space-y-6">
                <QuickStats />
                <RecommendationCards />
              </div>
            </div>
          )}

          {/* Interests Tab */}
          {activeTab === "interests" && (
            <div className="space-y-6">
              <InterestsList />
              <SuggestedInterests />
            </div>
          )}

          {/* Networking Tab */}
          {activeTab === "networking" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1 space-y-6">
                <NetworkOverview />
              </div>
              <div className="lg:col-span-2 space-y-6">
                <PeopleToFollow />
                <PostsToRead />
              </div>
            </div>
          )}

          {/* Jobs Tab */}
          {activeTab === "jobs" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1 space-y-6">
                <JobGoalsForm />
                <SkillsToLearn />
              </div>
              <div className="lg:col-span-2 space-y-6">
                <RecommendedJobs />
                <RecommendedCourses />
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default MainLayout;
