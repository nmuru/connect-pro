import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "../context/UserContext";
import { useLocation } from "wouter";
import { FaLinkedin } from "react-icons/fa";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { z } from "zod";

export default function LoginPage() {
  const { loginWithProfile, loading } = useUser();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [profileUrl, setProfileUrl] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const linkedinUrlSchema = z.string().url().includes("linkedin.com/");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Validate the LinkedIn URL
      linkedinUrlSchema.parse(profileUrl);
      
      setIsSubmitting(true);
      await loginWithProfile(profileUrl);
      toast({
        title: "Login successful",
        description: "Welcome to ConnectPro!",
      });
      setLocation("/app/home");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Invalid LinkedIn URL",
          description: "Please enter a valid LinkedIn profile URL",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Login failed",
          description: "An error occurred during login. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-neutral-100 dark:bg-neutral-800 transition-colors duration-300">
      <div className="absolute top-4 right-4">
        <ThemeToggle />
      </div>
      <Card className="w-full max-w-md shadow-lg">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-primary mb-2">ConnectPro</h1>
            <p className="text-neutral-500 dark:text-neutral-300">Professional networking made simple</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4 mb-6">
            <div className="space-y-2">
              <Label htmlFor="profileUrl">Enter your LinkedIn profile URL</Label>
              <Input
                id="profileUrl"
                type="url"
                placeholder="https://www.linkedin.com/in/yourprofile"
                value={profileUrl}
                onChange={(e) => setProfileUrl(e.target.value)}
                required
                className="w-full"
              />
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                We'll use this to create your profile in ConnectPro
              </p>
            </div>
            
            <Button
              type="submit"
              className="w-full flex items-center justify-center gap-2"
              disabled={loading || isSubmitting}
            >
              <FaLinkedin className="h-5 w-5" />
              {isSubmitting ? "Signing in..." : "Sign in with LinkedIn Profile"}
            </Button>
          </form>
          
          <div className="my-4 flex items-center">
            <div className="flex-grow border-t border-gray-300 dark:border-gray-600"></div>
            <span className="mx-4 text-sm text-gray-500 dark:text-gray-400">or</span>
            <div className="flex-grow border-t border-gray-300 dark:border-gray-600"></div>
          </div>
          
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              toast({
                title: "Demo Mode",
                description: "Logging in with demo profile",
              });
              loginWithProfile("demo");
              setLocation("/app/home");
            }}
          >
            Continue with Demo Profile
          </Button>
          
          <p className="text-sm text-neutral-500 dark:text-neutral-400 text-center mt-6">
            By signing in, you agree to our <a href="#" className="text-primary hover:underline">Terms of Service</a> and <a href="#" className="text-primary hover:underline">Privacy Policy</a>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
