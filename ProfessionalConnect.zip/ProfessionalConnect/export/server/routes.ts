import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertJobPreferenceSchema, insertUserInterestSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok" });
  });
  
  // Simple test routes
  app.get("/simple", (_req, res) => {
    res.sendFile("simple-test.html", { root: '.' });
  });
  
  // Dummy UI navigation route
  app.get("/dummy", (_req, res) => {
    res.sendFile("dummy-ui.html", { root: '.' });
  });
  
  // Test route
  app.get("/test", (_req, res) => {
    res.sendFile("test.html", { root: '.' });
  });
  
  // Static preview route
  app.get("/preview", (_req, res) => {
    res.sendFile("preview.html", { root: '.' });
  });

  // User routes
  app.get("/api/users/:id", async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/users", async (req, res, next) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      next(error);
    }
  });

  // Job preferences routes
  app.post("/api/users/:id/job-preferences", async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const jobPreferenceData = insertJobPreferenceSchema.parse({
        ...req.body,
        userId
      });

      const jobPreference = await storage.saveJobPreferences(jobPreferenceData);
      res.status(201).json(jobPreference);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      next(error);
    }
  });

  // User interests routes
  app.post("/api/users/:id/interests", async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const { interestIds } = z.object({ 
        interestIds: z.array(z.number()) 
      }).parse(req.body);

      const results = await Promise.all(
        interestIds.map(interestId => 
          storage.addUserInterest({ userId, interestId })
        )
      );

      res.status(201).json(results);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: fromZodError(error).message 
        });
      }
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
