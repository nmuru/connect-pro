import { 
  User, InsertUser, 
  JobPreference, InsertJobPreference,
  Interest, InsertInterest,
  UserInterest, InsertUserInterest,
  Skill, InsertSkill,
  UserSkill, InsertUserSkill,
  Education, InsertEducation,
  Experience, InsertExperience
} from "@shared/schema";

export interface IStorage {
  // User CRUD
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByLinkedinId(linkedinId: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User>;
  
  // Job preferences
  getJobPreferences(userId: number): Promise<JobPreference | undefined>;
  saveJobPreferences(jobPreference: InsertJobPreference): Promise<JobPreference>;
  
  // Interests
  getInterests(): Promise<Interest[]>;
  getInterestsByCategory(category: string): Promise<Interest[]>;
  getUserInterests(userId: number): Promise<Interest[]>;
  addUserInterest(userInterest: InsertUserInterest): Promise<UserInterest>;
  removeUserInterest(userId: number, interestId: number): Promise<void>;
  
  // Skills
  getSkills(): Promise<Skill[]>;
  getSkillsByCategory(category: string): Promise<Skill[]>;
  getUserSkills(userId: number): Promise<{ skill: Skill; endorsements: number }[]>;
  addUserSkill(userSkill: InsertUserSkill): Promise<UserSkill>;
  removeUserSkill(userId: number, skillId: number): Promise<void>;
  
  // Education
  getUserEducation(userId: number): Promise<Education[]>;
  addEducation(education: InsertEducation): Promise<Education>;
  updateEducation(id: number, education: Partial<Education>): Promise<Education>;
  removeEducation(id: number): Promise<void>;
  
  // Experience
  getUserExperience(userId: number): Promise<Experience[]>;
  addExperience(experience: InsertExperience): Promise<Experience>;
  updateExperience(id: number, experience: Partial<Experience>): Promise<Experience>;
  removeExperience(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private jobPreferences: Map<number, JobPreference>;
  private interests: Map<number, Interest>;
  private userInterests: Map<string, UserInterest>;
  private skills: Map<number, Skill>;
  private userSkills: Map<string, UserSkill>;
  private educations: Map<number, Education>;
  private experiences: Map<number, Experience>;
  
  private userId: number = 1;
  private jobPrefId: number = 1;
  private interestId: number = 1;
  private userInterestId: number = 1;
  private skillId: number = 1;
  private userSkillId: number = 1;
  private educationId: number = 1;
  private experienceId: number = 1;

  constructor() {
    this.users = new Map();
    this.jobPreferences = new Map();
    this.interests = new Map();
    this.userInterests = new Map();
    this.skills = new Map();
    this.userSkills = new Map();
    this.educations = new Map();
    this.experiences = new Map();
    
    // Initialize with some sample data
    this.initSampleData();
  }

  private initSampleData() {
    // Add sample interests
    const sampleInterests: [string, string][] = [
      ['Artificial Intelligence', 'Technology'],
      ['Cloud Computing', 'Technology'],
      ['Cybersecurity', 'Technology'],
      ['Machine Learning', 'Technology'],
      ['Startups', 'Business'],
      ['Leadership', 'Business'],
      ['Digital Marketing', 'Business'],
      ['Product Management', 'Business'],
      ['Remote Work', 'Career Development'],
      ['Freelancing', 'Career Development'],
      ['Salary Negotiation', 'Career Development'],
      ['Interview Preparation', 'Career Development']
    ];
    
    sampleInterests.forEach(([name, category]) => {
      const id = this.interestId++;
      this.interests.set(id, {
        id,
        name,
        category
      });
    });
    
    // Add sample skills
    const sampleSkills: [string, string][] = [
      ['JavaScript', 'Programming'],
      ['React', 'Frontend'],
      ['Node.js', 'Backend'],
      ['Python', 'Programming'],
      ['Cloud Architecture', 'Infrastructure'],
      ['React Native', 'Mobile'],
      ['GraphQL', 'API'],
      ['Kubernetes', 'DevOps']
    ];
    
    sampleSkills.forEach(([name, category]) => {
      const id = this.skillId++;
      this.skills.set(id, {
        id,
        name,
        category
      });
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }

  async getUserByLinkedinId(linkedinId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.linkedinId === linkedinId
    );
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.googleId === googleId
    );
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = {
      ...userData,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    const updatedUser: User = {
      ...user,
      ...userData,
      id, // Ensure ID doesn't change
      updatedAt: new Date()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Job preferences methods
  async getJobPreferences(userId: number): Promise<JobPreference | undefined> {
    return Array.from(this.jobPreferences.values()).find(
      (pref) => pref.userId === userId
    );
  }

  async saveJobPreferences(jobPreference: InsertJobPreference): Promise<JobPreference> {
    // Check if user already has preferences
    const existing = await this.getJobPreferences(jobPreference.userId);
    
    if (existing) {
      // Update existing preferences
      const updated: JobPreference = {
        ...existing,
        ...jobPreference,
        id: existing.id // Ensure ID doesn't change
      };
      this.jobPreferences.set(existing.id, updated);
      return updated;
    }
    
    // Create new preferences
    const id = this.jobPrefId++;
    const newJobPreference: JobPreference = {
      ...jobPreference,
      id
    };
    this.jobPreferences.set(id, newJobPreference);
    return newJobPreference;
  }

  // Interests methods
  async getInterests(): Promise<Interest[]> {
    return Array.from(this.interests.values());
  }

  async getInterestsByCategory(category: string): Promise<Interest[]> {
    return Array.from(this.interests.values()).filter(
      (interest) => interest.category === category
    );
  }

  async getUserInterests(userId: number): Promise<Interest[]> {
    const userInterestIds = Array.from(this.userInterests.values())
      .filter((ui) => ui.userId === userId)
      .map((ui) => ui.interestId);
    
    return userInterestIds.map((id) => this.interests.get(id)!)
      .filter(Boolean);
  }

  async addUserInterest(userInterest: InsertUserInterest): Promise<UserInterest> {
    // Check if already exists
    const key = `${userInterest.userId}-${userInterest.interestId}`;
    const existing = Array.from(this.userInterests.values()).find(
      (ui) => ui.userId === userInterest.userId && ui.interestId === userInterest.interestId
    );
    
    if (existing) {
      return existing;
    }
    
    const id = this.userInterestId++;
    const newUserInterest: UserInterest = {
      ...userInterest,
      id
    };
    this.userInterests.set(key, newUserInterest);
    return newUserInterest;
  }

  async removeUserInterest(userId: number, interestId: number): Promise<void> {
    const key = `${userId}-${interestId}`;
    this.userInterests.delete(key);
  }

  // Skills methods
  async getSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values());
  }

  async getSkillsByCategory(category: string): Promise<Skill[]> {
    return Array.from(this.skills.values()).filter(
      (skill) => skill.category === category
    );
  }

  async getUserSkills(userId: number): Promise<{ skill: Skill; endorsements: number }[]> {
    const userSkillsData = Array.from(this.userSkills.values())
      .filter((us) => us.userId === userId);
    
    return userSkillsData.map((us) => ({
      skill: this.skills.get(us.skillId)!,
      endorsements: us.endorsements || 0
    })).filter((item) => item.skill);
  }

  async addUserSkill(userSkill: InsertUserSkill): Promise<UserSkill> {
    // Check if already exists
    const key = `${userSkill.userId}-${userSkill.skillId}`;
    const existing = Array.from(this.userSkills.values()).find(
      (us) => us.userId === userSkill.userId && us.skillId === userSkill.skillId
    );
    
    if (existing) {
      return existing;
    }
    
    const id = this.userSkillId++;
    const newUserSkill: UserSkill = {
      ...userSkill,
      id
    };
    this.userSkills.set(key, newUserSkill);
    return newUserSkill;
  }

  async removeUserSkill(userId: number, skillId: number): Promise<void> {
    const key = `${userId}-${skillId}`;
    this.userSkills.delete(key);
  }

  // Education methods
  async getUserEducation(userId: number): Promise<Education[]> {
    return Array.from(this.educations.values())
      .filter((edu) => edu.userId === userId);
  }

  async addEducation(education: InsertEducation): Promise<Education> {
    const id = this.educationId++;
    const newEducation: Education = {
      ...education,
      id
    };
    this.educations.set(id, newEducation);
    return newEducation;
  }

  async updateEducation(id: number, educationData: Partial<Education>): Promise<Education> {
    const education = this.educations.get(id);
    if (!education) {
      throw new Error(`Education with ID ${id} not found`);
    }
    
    const updatedEducation: Education = {
      ...education,
      ...educationData,
      id
    };
    
    this.educations.set(id, updatedEducation);
    return updatedEducation;
  }

  async removeEducation(id: number): Promise<void> {
    this.educations.delete(id);
  }

  // Experience methods
  async getUserExperience(userId: number): Promise<Experience[]> {
    return Array.from(this.experiences.values())
      .filter((exp) => exp.userId === userId);
  }

  async addExperience(experience: InsertExperience): Promise<Experience> {
    const id = this.experienceId++;
    const newExperience: Experience = {
      ...experience,
      id
    };
    this.experiences.set(id, newExperience);
    return newExperience;
  }

  async updateExperience(id: number, experienceData: Partial<Experience>): Promise<Experience> {
    const experience = this.experiences.get(id);
    if (!experience) {
      throw new Error(`Experience with ID ${id} not found`);
    }
    
    const updatedExperience: Experience = {
      ...experience,
      ...experienceData,
      id
    };
    
    this.experiences.set(id, updatedExperience);
    return updatedExperience;
  }

  async removeExperience(id: number): Promise<void> {
    this.experiences.delete(id);
  }
}

export const storage = new MemStorage();
