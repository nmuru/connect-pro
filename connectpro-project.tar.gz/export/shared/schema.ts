import { pgTable, text, serial, integer, boolean, json, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  profilePicture: text("profile_picture"),
  headline: text("headline"),
  location: text("location"),
  currentCompany: text("current_company"),
  currentTitle: text("current_title"),
  industry: text("industry"),
  about: text("about"),
  linkedinId: text("linkedin_id").unique(),
  googleId: text("google_id").unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Skills table
export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category"),
});

export const insertSkillSchema = createInsertSchema(skills).omit({
  id: true,
});

// User Skills relation
export const userSkills = pgTable("user_skills", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  skillId: integer("skill_id").notNull().references(() => skills.id),
  endorsements: integer("endorsements").default(0),
});

export const insertUserSkillSchema = createInsertSchema(userSkills).omit({
  id: true,
});

// Interests table
export const interests = pgTable("interests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(),
});

export const insertInterestSchema = createInsertSchema(interests).omit({
  id: true,
});

// User Interests relation
export const userInterests = pgTable("user_interests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  interestId: integer("interest_id").notNull().references(() => interests.id),
});

export const insertUserInterestSchema = createInsertSchema(userInterests).omit({
  id: true,
});

// Job Preferences
export const jobPreferences = pgTable("job_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id).unique(),
  desiredRole: text("desired_role"),
  desiredLocation: text("desired_location"),
  desiredIndustry: text("desired_industry"),
  fullTime: boolean("full_time").default(true),
  partTime: boolean("part_time").default(false),
  remote: boolean("remote").default(false),
  contract: boolean("contract").default(false),
  salaryRange: text("salary_range"),
});

export const insertJobPreferenceSchema = createInsertSchema(jobPreferences).omit({
  id: true,
});

// Education
export const education = pgTable("education", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  school: text("school").notNull(),
  degree: text("degree"),
  fieldOfStudy: text("field_of_study"),
  startYear: text("start_year"),
  endYear: text("end_year"),
});

export const insertEducationSchema = createInsertSchema(education).omit({
  id: true,
});

// Experience
export const experience = pgTable("experience", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location"),
  startDate: text("start_date"),
  endDate: text("end_date"),
  current: boolean("current").default(false),
  description: text("description"),
});

export const insertExperienceSchema = createInsertSchema(experience).omit({
  id: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSkill = z.infer<typeof insertSkillSchema>;
export type Skill = typeof skills.$inferSelect;

export type InsertUserSkill = z.infer<typeof insertUserSkillSchema>;
export type UserSkill = typeof userSkills.$inferSelect;

export type InsertInterest = z.infer<typeof insertInterestSchema>;
export type Interest = typeof interests.$inferSelect;

export type InsertUserInterest = z.infer<typeof insertUserInterestSchema>;
export type UserInterest = typeof userInterests.$inferSelect;

export type InsertJobPreference = z.infer<typeof insertJobPreferenceSchema>;
export type JobPreference = typeof jobPreferences.$inferSelect;

export type InsertEducation = z.infer<typeof insertEducationSchema>;
export type Education = typeof education.$inferSelect;

export type InsertExperience = z.infer<typeof insertExperienceSchema>;
export type Experience = typeof experience.$inferSelect;
