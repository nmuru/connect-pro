import { useUser } from "@/context/UserContext";
import { BellIcon, MailIcon } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { UserAvatar } from "@/components/ui/user-avatar";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function Header() {
  const { profile, logout } = useUser();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out successfully",
      description: "You have been logged out of your account",
    });
    setLocation("/");
  };

  const handleNotificationsClick = () => {
    toast({
      title: "Notifications",
      description: "You have no new notifications",
    });
  };

  const handleMessagesClick = () => {
    toast({
      title: "Messages",
      description: "You have no new messages",
    });
  };

  return (
    <header className="bg-white dark:bg-neutral-700 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-3 md:py-4">
          <div className="flex items-center">
            <Link href="/app/home">
              <h1 className="text-2xl font-bold text-primary cursor-pointer">ConnectPro</h1>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleNotificationsClick}
              className="text-neutral-500 dark:text-neutral-300 hover:text-primary dark:hover:text-primary"
            >
              <BellIcon className="h-5 w-5" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={handleMessagesClick}
              className="text-neutral-500 dark:text-neutral-300 hover:text-primary dark:hover:text-primary"
            >
              <MailIcon className="h-5 w-5" />
            </Button>
            
            <ThemeToggle />
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <UserAvatar 
                    user={{ 
                      name: profile?.name || "User", 
                      image: profile?.profilePicture 
                    }} 
                    className="h-8 w-8" 
                  />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <Link href="/app/home">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Link href="/app/settings">Settings</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}
