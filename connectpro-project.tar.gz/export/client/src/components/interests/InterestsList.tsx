import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { interestCategories as initialInterestCategories } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

export default function InterestsList() {
  const [interestCategories, setInterestCategories] = useState(initialInterestCategories);
  const { toast } = useToast();

  const handleCheckboxChange = (categoryIndex: number, topicIndex: number) => {
    const updatedCategories = [...interestCategories];
    updatedCategories[categoryIndex].topics[topicIndex].checked = 
      !updatedCategories[categoryIndex].topics[topicIndex].checked;
    
    setInterestCategories(updatedCategories);
  };

  const handleResetInterests = () => {
    setInterestCategories(initialInterestCategories);
    toast({
      title: "Interests Reset",
      description: "Your interests have been reset to defaults.",
    });
  };

  const handleSaveInterests = () => {
    toast({
      title: "Interests Saved",
      description: "Your interest preferences have been saved successfully!",
    });
  };

  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <h2 className="text-lg font-bold mb-2">Your Interests</h2>
        <p className="text-neutral-500 dark:text-neutral-400 mb-4">
          Select topics that interest you to get personalized recommendations
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {interestCategories.map((category, categoryIndex) => (
            <div key={category.name} className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-lg">
              <h3 className="font-medium mb-3">{category.name}</h3>
              <div className="space-y-2">
                {category.topics.map((topic, topicIndex) => (
                  <div key={topic.id} className="flex items-center">
                    <Checkbox 
                      id={topic.id} 
                      checked={topic.checked}
                      onCheckedChange={() => handleCheckboxChange(categoryIndex, topicIndex)}
                      className="mr-2"
                    />
                    <Label htmlFor={topic.id} className="text-sm cursor-pointer">
                      {topic.label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-between">
          <Button 
            variant="outline" 
            className="text-neutral-800 dark:text-neutral-200"
            onClick={handleResetInterests}
          >
            Reset to Defaults
          </Button>
          <Button onClick={handleSaveInterests}>
            Save Preferences
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
