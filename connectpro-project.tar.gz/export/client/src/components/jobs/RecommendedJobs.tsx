import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookmarkIcon, FilterIcon, ExternalLinkIcon } from "lucide-react";
import { recommendedJobs as initialRecommendedJobs } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

export default function RecommendedJobs() {
  const [jobs, setJobs] = useState(initialRecommendedJobs);
  const { toast } = useToast();

  const handleSaveJob = (jobId: string) => {
    setJobs(jobs.map(job => 
      job.id === jobId ? { ...job, saved: !job.saved } : job
    ));
    
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      toast({
        title: job.saved ? "Job removed from saved" : "Job saved",
        description: job.saved 
          ? `${job.title} has been removed from your saved jobs.` 
          : `${job.title} has been saved for later.`,
      });
    }
  };

  const handleApplyForJob = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      toast({
        title: "Application Started",
        description: `You are now applying for ${job.title} at ${job.company}.`,
      });
    }
  };

  const handleViewAll = () => {
    toast({
      title: "View All Jobs",
      description: "Viewing all jobs feature coming soon!",
    });
  };

  const handleFilter = () => {
    toast({
      title: "Filter Jobs",
      description: "Job filtering functionality coming soon!",
    });
  };

  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold">Recommended Jobs</h2>
          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="mr-3" onClick={handleFilter}>
              <FilterIcon className="h-4 w-4 text-neutral-400 hover:text-neutral-500 dark:text-neutral-500 dark:hover:text-neutral-400" />
            </Button>
            <Button variant="link" className="text-primary" onClick={handleViewAll}>
              View All
            </Button>
          </div>
        </div>
        
        <div className="space-y-4">
          {jobs.map(job => (
            <div key={job.id} className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-lg">
              <div className="flex items-start">
                <div className="h-12 w-12 bg-white dark:bg-neutral-700 rounded-md flex items-center justify-center mr-4">
                  <img 
                    src={job.companyLogo} 
                    alt={job.company} 
                    className="h-10 w-10 object-contain"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <h3 className="font-medium">{job.title}</h3>
                    <span className="text-sm text-green-500 font-medium">{job.salary}</span>
                  </div>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">{job.company} • {job.location}</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {job.skills.map((skill, index) => (
                      <span 
                        key={index} 
                        className="bg-primary-100 dark:bg-primary-700 text-primary-800 dark:text-primary-200 text-xs px-2 py-1 rounded-full"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                  <div className="mt-3 flex justify-between items-center">
                    <span className="text-xs text-neutral-500 dark:text-neutral-400">
                      Posted {job.postedTime} • {job.applicants} applicants
                    </span>
                    <div className="flex space-x-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className={job.saved ? "text-primary" : "text-neutral-500 dark:text-neutral-300 hover:text-neutral-700 dark:hover:text-neutral-100"}
                        onClick={() => handleSaveJob(job.id)}
                      >
                        <BookmarkIcon className="h-4 w-4" fill={job.saved ? "currentColor" : "none"} />
                      </Button>
                      <Button 
                        size="sm"
                        className="flex items-center gap-1"
                        onClick={() => handleApplyForJob(job.id)}
                      >
                        Apply Now
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
