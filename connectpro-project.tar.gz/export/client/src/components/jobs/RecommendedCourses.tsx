import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CodeIcon, CloudIcon, StarIcon, StarHalfIcon } from "lucide-react";
import { recommendedCourses } from "@/data/mockData";
import { useToast } from "@/hooks/use-toast";

export default function RecommendedCourses() {
  const { toast } = useToast();

  const handleViewAll = () => {
    toast({
      title: "View All Courses",
      description: "Viewing all courses feature coming soon!",
    });
  };

  const handleExploreCourse = (courseTitle: string) => {
    toast({
      title: "Course Started",
      description: `You are now learning "${courseTitle}".`,
    });
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<StarIcon key={`star-${i}`} className="h-3 w-3 fill-yellow-400 text-yellow-400" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalfIcon key="half-star" className="h-3 w-3 fill-yellow-400 text-yellow-400" />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<StarIcon key={`empty-star-${i}`} className="h-3 w-3 text-yellow-400" />);
    }
    
    return stars;
  };

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'code':
        return <CodeIcon className="text-primary text-2xl" />;
      case 'cloud':
        return <CloudIcon className="text-primary text-2xl" />;
      default:
        return <CodeIcon className="text-primary text-2xl" />;
    }
  };

  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold">Recommended Courses</h2>
          <Button variant="link" className="text-primary" onClick={handleViewAll}>
            View All
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendedCourses.map(course => (
            <div key={course.id} className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-lg flex">
              <div className="h-16 w-16 bg-primary-100 dark:bg-primary-700 flex items-center justify-center rounded-md mr-4">
                {getIconComponent(course.icon)}
              </div>
              <div className="flex-1">
                <h3 className="font-medium">{course.title}</h3>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">
                  {course.provider} • {course.duration}
                </p>
                <div className="mt-2 flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="flex mr-1">
                      {renderStars(course.rating)}
                    </div>
                    <span className="text-xs text-neutral-500 dark:text-neutral-400">
                      {course.rating} ({course.reviews.toLocaleString()})
                    </span>
                  </div>
                  <Button 
                    variant="link" 
                    className="text-primary text-sm font-medium p-0"
                    onClick={() => handleExploreCourse(course.title)}
                  >
                    Start
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
