import { Card, CardContent } from "@/components/ui/card";
import { quickStats } from "@/data/mockData";

export default function QuickStats() {
  return (
    <Card className="transition-all duration-300 hover:shadow-md">
      <CardContent className="p-6">
        <h2 className="text-lg font-bold mb-4">Quick Stats</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-md text-center">
            <p className="text-2xl font-bold text-primary">{quickStats.profileViews}</p>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">Profile Views</p>
          </div>
          <div className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-md text-center">
            <p className="text-2xl font-bold text-primary">{quickStats.profileCompletion}%</p>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">Profile Completion</p>
          </div>
          <div className="bg-neutral-50 dark:bg-neutral-600 p-4 rounded-md text-center">
            <p className="text-2xl font-bold text-primary">{quickStats.newConnections}</p>
            <p className="text-sm text-neutral-500 dark:text-neutral-400">New Connections</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
