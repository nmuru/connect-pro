import React, { createContext, useContext, useEffect, useState } from "react";
import { ProfileData, profileData } from "../data/mockData";

interface UserContextType {
  isAuthenticated: boolean;
  profile: ProfileData | null;
  loading: boolean;
  loginWithProfile: (profileUrl: string) => Promise<void>;
  logout: () => void;
}

const UserContext = createContext<UserContextType>({
  isAuthenticated: false,
  profile: null,
  loading: false,
  loginWithProfile: async () => {},
  logout: () => {},
});

export const useUser = () => useContext(UserContext);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  // Check localStorage for existing session on mount
  useEffect(() => {
    const storedAuth = localStorage.getItem("auth");
    const storedProfile = localStorage.getItem("profile");
    
    if (storedAuth === "true" && storedProfile) {
      setIsAuthenticated(true);
      setProfile(JSON.parse(storedProfile));
    }
  }, []);

  // Function to extract username from LinkedIn URL
  const extractLinkedInUsername = (url: string): string => {
    try {
      // Handle demo profile case
      if (url === "demo") return "demo";
      
      // Extract username from URL like https://www.linkedin.com/in/username
      const regex = /linkedin\.com\/in\/([^\/]+)/;
      const match = url.match(regex);
      return match ? match[1] : "";
    } catch (error) {
      console.error("Error extracting LinkedIn username:", error);
      return "";
    }
  };

  const loginWithProfile = async (profileUrl: string) => {
    setLoading(true);
    
    try {
      // Simulate API call to fetch profile data
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Extract username from LinkedIn URL
      const username = extractLinkedInUsername(profileUrl);
      
      if (!username) {
        throw new Error("Invalid LinkedIn profile URL");
      }
      
      // For demo purposes, use the mock profile data
      // In a real app, this would use the username to fetch profile data from an API
      const userProfile = {
        ...profileData,
        // If it's the demo profile, keep the original data, otherwise customize it
        ...(username !== "demo" && {
          id: `user-${Date.now()}`,
          name: username.split('-').map(part => 
            part.charAt(0).toUpperCase() + part.slice(1)
          ).join(' '),
          headline: `Professional at ${username.toUpperCase()} Industries`,
        })
      };
      
      setProfile(userProfile);
      setIsAuthenticated(true);
      
      // Store in localStorage for persistence
      localStorage.setItem("auth", "true");
      localStorage.setItem("profile", JSON.stringify(userProfile));
    } catch (error) {
      console.error("Login failed:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
    setProfile(null);
    localStorage.removeItem("auth");
    localStorage.removeItem("profile");
  };

  return (
    <UserContext.Provider value={{ isAuthenticated, profile, loading, loginWithProfile, logout }}>
      {children}
    </UserContext.Provider>
  );
};
