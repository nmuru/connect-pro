import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import { useUser } from "./context/UserContext";
import LoginPage from "./pages/LoginPage";
import MainLayout from "./pages/MainLayout";
import NotFound from "./pages/not-found";

// Simple test component to see if routing is working
function TestComponent() {
  return (
    <div style={{ padding: '40px', textAlign: 'center', fontFamily: 'sans-serif', maxWidth: '800px', margin: '0 auto' }}>
      <h1>ConnectPro Networking App</h1>
      <p>This is a test page to confirm the application is working correctly.</p>
      <div style={{ margin: '20px 0', padding: '20px', backgroundColor: '#f5f5f5', borderRadius: '8px' }}>
        <h2>Login Page Features</h2>
        <ul style={{ textAlign: 'left', lineHeight: '1.6' }}>
          <li>Enter your LinkedIn profile URL (e.g., https://www.linkedin.com/in/yourprofile)</li>
          <li>Sign in with LinkedIn Profile button</li>
          <li>"Continue with Demo Profile" option for easy testing</li>
          <li>Theme toggle for dark/light mode</li>
        </ul>
      </div>
      <p>The server is working correctly, but you may be experiencing a Replit domain resolution issue.</p>
    </div>
  );
}

function Router() {
  const [location] = useLocation();
  const { isAuthenticated } = useUser();
  const { toast } = useToast();

  // Simple authentication flow
  useEffect(() => {
    if (!isAuthenticated && location !== "/" && location !== "/test") {
      toast({
        title: "Authentication required",
        description: "Please sign in to continue.",
        variant: "destructive",
      });
    }
  }, [isAuthenticated, location, toast]);

  return (
    <Switch>
      <Route path="/test" component={TestComponent} />
      <Route path="/" component={LoginPage} />
      <Route path="/app/:tab*" component={isAuthenticated ? MainLayout : LoginPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
